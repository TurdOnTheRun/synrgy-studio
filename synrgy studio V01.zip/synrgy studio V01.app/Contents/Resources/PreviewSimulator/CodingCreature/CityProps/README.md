Place the extracted free `city-props-1-free.zip` contents from
`https://codingcreature.itch.io/city-props-kit-1`
in this directory.

Keep the pack's internal folder structure intact.

The preview simulator scans this folder recursively for `.obj` props.
